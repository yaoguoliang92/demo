vcastr 3.0 help
http://www.ruochi.com/main/2008/03/19/vcastr-30/